# pydictionaryclassifier
A Python module to create classes and objects out of dictionaries.
